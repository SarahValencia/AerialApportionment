#' @title CensusVariableSearch 
#' 
#' @description This function allows users to search for variables by narrowing down the available options provided in the tidyCensus load_variables function.
#' 
#' @details The load_variables function allows users to select a dataset and year, but provides no additional means of filtering the thousands of variables that may be present. This function builds on the load_variables function to provide users a way to filter the variable table to reduce the number of variables shown. 
#' 
#' @param Yr The end year of the survey you are pulling data from.
#' @param dataset Survey type, which can be "acs5", "acs3", or "acs1". Defailts to "acs5".
#' @param variableCode Character string or vector of character strings that can be used to search for a variable if you already know the code. For example, you can check if a code used from a previous survey is still valid.
#' @param geog_var Optional string specifying the geography of the variable you are searching for, as this can help narrow results.
#' @param conceptSearch Character string or vector of character strings representing a word or phrase found in the "concept" column of the variable table. Useful concept search terms include "Total population", "Median Household Income", "Race". 
#' @param labelSearch Character string or vector of character strings representing a word or phrase found in the "label" column of the variable table.
#' 
#' @returns A four column tibble of variables from the requested dataset, filtered by the search terms. If there are no matching search terms a warning will appear and an empty tibble will appear.
#' 
#' @examples
#' CensusVariableSearch(Yr=2021, dataset="acs5", geog_var = "block group", conceptSearch = "Race")
#' 
#' CensusVariableSearch(Yr=2021, dataset="acs5", variableCode = "B02001_001")
#' 
#' CensusVariableSearch(Yr=2021, dataset="acs5", geog_var = "block group", conceptSearch = "Education")
#' 
#' @export
CensusVariableSearch <- function(Yr, dataset="acs5", variableCode = NULL, geog_var = NULL, conceptSearch = NULL, labelSearch = NULL){
  
  VariablesTbl <- load_variables(year=Yr, dataset, cache = TRUE)
  
  if(!is.null(geog_var)){  
    VariablesTbl <- VariablesTbl %>% filter(geography == geog_var)
    
    if(dim(VariablesTbl)[1] == 0){
      print_color("No matching geography.\n","red")
      return(VariablesTbl)
    }
  }
  
  if(!is.null(variableCode)){ 
    VariablesTbl <- VariablesTbl %>% filter(name == variableCode)
    
    if(dim(VariablesTbl)[1] == 0){
      print_color("No matching variable codes.\n","red")
      return(VariablesTbl)
    }
  }
  
  if(!is.null(conceptSearch)){ 
    
    #decapitilize search 
    searchTerms <- tolower(conceptSearch)
    
    # This code decapitalizes the names in the table to elimiminate needing to match capitilizations.
    VariablesTbl <- VariablesTbl[unlist(sapply(searchTerms, grep, tolower(VariablesTbl$concept), USE.NAMES = F)), ]
    
    if(dim(VariablesTbl)[1] == 0){
      print_color("No matching search terms.\n","red")
      return(VariablesTbl)
    }
  }  # end if VarNameSearch
  
  if(!is.null(labelSearch)){ 
    
    #decapitilize search 
    searchTerms <- tolower(labelSearch)
    
    # This code decapitalizes the names in the table to elimiminate needing to match capitilizations.
    VariablesTbl <- VariablesTbl[unlist(sapply(searchTerms, grep, tolower(VariablesTbl$label), USE.NAMES = F)), ]
    
    if(dim(VariablesTbl)[1] == 0){
      print_color("No matching search terms.\n","red")
      return(VariablesTbl)
    }
  }  # end if labelSearch
  
    return(VariablesTbl)
}  # end function
