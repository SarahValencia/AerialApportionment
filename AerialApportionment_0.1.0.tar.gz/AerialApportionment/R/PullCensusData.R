#' @title PullCensusData
#'
#' @description This function allows users to obtain data and feature geometry from the american community survey (ACS) and organize that data for use in spatial buffering operations.
#'
#' @details This function is specifically designed to organize census data in order to calculate the number of people in different demographics that live within a specified range (buffer) of TRI facilities. It uses the get_acs function in the tidycensus package, which allows users to access to the 1-year and 5-year American Community Survey APIs. at the time frame, geographic scale, and location specified by the user. Users also have the option to project the returned data into different geographic coordinate systems.
#'
#' @param EndYr The year, or endyear, of the ACS sample. 5-year ACS data is available from 2009 through 2021; 1-year ACS data is available from 2005 through 2021, with the exception of 2020. Defaults to 2021.
#'
#' @param acsGeog is a character string that specifies one of the geography inputs for the get_acs function in the tidyCensus package (complete list here: https://walker-data.com/tidycensus/articles/basic-usage.html)
#'
#' @param stateList is a vector of character stings specifying 2 letter FIPS codes for states. Data is downloaded on a state by state basis so a vector of all desired states and territories must be provided.
#'
#' @param countyList The county for which you are requesting data. County names and FIPS codes are accepted. Must be combined with a value supplied to 'state'. Defaults to NULL
#'
#' @param variableCodes Character string or vector of character strings of variable IDs. tidycensus automatically returns the estimate and the margin of error associated with the variable.
#' 
#' @param surveyType Specifies the type of survey the data should be pulled from. The ACS contains one-year, three-year, and five-year surveys expressed as "acs1", "acs3", and "acs5". The default selection is "acs5."
#'
#' @param EPSGcode Users can provide a EPSG code if they would like the data projected from Lat/Long (NAD83) to another coordinate system.
#'
#' @returns A sf tibble of ACS data. While the get_acs function can return data in a "tidy" format in which each row represents an enumeration unit-variable combination, the PullCensusData function returns data in a "wide" format in which each row represents an enumeration unit and the variables are in the columns. The data is also saved as an .rds file in the current working directory.
#'
#' @examples
#' # Set your api key using the command census_api_key("YOUR KEY GOES HERE") 
#' # before running PullCensusData.
#'
#' PullCensusData(2020, acsGeog = "block group", stateList = "CA",  variableCodes= 
#' c("population" = "B01001_001"), surveyType="acs5", EPSGcode=4269)
#'
#' @export
PullCensusData <- function(EndYr, acsGeog = "block group", stateList, countyList=NULL, variableCodes, surveyType="acs5", EPSGcode=4269){

  # create empty list to fill with data from loop
  datalist <- list()

  for(i in 1:length(stateList)){  #for each state or territory
    dataGrab <- get_acs(   #use get_acs function to pull list of variables
      geography = acsGeog,
      state = stateList[i],  # even if looking for one county need to list a state
      county = countyList,
      variables = variableCodes,
      year = EndYr,
      geometry = TRUE ,
      output = "wide",  # get data in wide format for easier mapping
      survey = surveyType,
    )  %>% st_transform(EPSGcode)
    datalist[[i]] <- dataGrab   #Stick each state in a big list
  }


  # combine list into df
  census_by_geog <- do.call(rbind, datalist)


  saveRDS(census_by_geog, file = paste("census_",acsGeog, "_", EndYr, ".rds", sep=""))


  ## return  data for future analysis.
  return(census_by_geog)
}
